/**
 * carify theme JS
 * - small interactions: mobile menu, car gallery, contact form enhancements
 */
(function (Drupal, $) {
  Drupal.behaviors.carify = {
    attach: function (context, settings) {
      // Simple attach-once helper
      function attachOnce($elements, key, attachFn) {
        $elements.each(function () {
          var $el = $(this);
          if ($el.data(key)) { return; }
          $el.data(key, true);
          attachFn.call(this, $el);
        });
      }

      // Gallery thumbnails (if present)
      attachOnce($('.car-gallery .thumb', context), 'carify-thumb', function ($el) {
        $el.on('click', function () {
          var src = $el.data('src');
          if (src) { $('.car-gallery .main-img').attr('src', src); }
        });
      });

      // Mobile filter toggle
      attachOnce($('.carify-toggle-filters', context), 'carify-tog', function ($el) {
        $el.on('click', function () { $('.carify-filters').toggleClass('open'); });
      });

      // Purchase flow
      var $carData = $('#car-data', context);
      if ($carData.length) {
        attachOnce($carData, 'carify-purchase-init', function ($carDataEl) {
          var $existingBtn = $('#purchase-btn', context);
          var $purchaseBtn;
          var $formContainer = $('#purchase-form-container', context);

          if ($existingBtn.length) {
            $purchaseBtn = $existingBtn.show();
            if (!$formContainer.length) { $formContainer = $('<div/>', { id: 'purchase-form-container' }).insertAfter($purchaseBtn); }
          } else {
            $purchaseBtn = $('<button/>', { id: 'purchase-btn', class: 'button purchase-btn', text: 'Purchase' }).insertAfter($carDataEl);
            $formContainer = $('<div/>', { id: 'purchase-form-container' }).insertAfter($purchaseBtn);
          }

          attachOnce($purchaseBtn, 'carify-purchase-btn', function ($btn) {
            $btn.on('click', function (e) {
              e.preventDefault();

              // Determine allowed user (simple permissive check)
              var ds = (typeof drupalSettings !== 'undefined') ? drupalSettings : (typeof settings !== 'undefined' ? settings : null);
              var isCustomer = ($carDataEl.data('customerRole') || '').toString().toLowerCase() === 'customer';
              if (!isCustomer && ds && ds.user && ds.user.uid && parseInt(ds.user.uid) > 0) { isCustomer = true; }
              if (!isCustomer) {
                var $note = $('<div/>', { text: 'Only customers can purchase. Please log in as a Customer.', css: { background: '#f44336', color: '#fff', padding: '10px', position: 'fixed', top: '20px', right: '20px', zIndex: 9999, borderRadius: '4px' } });
                $('body').append($note); setTimeout(function () { $note.remove(); }, 3500); return;
              }

              if ($('#purchase-form', context).length) { return; }

              // Build form
              var formHtml = '\n<form id="purchase-form" class="purchase-form">\n  <h3>Purchase Car</h3>\n  <label>Name:</label>\n  <input type="text" name="name" value="' + ($carDataEl.data('customerName') || '') + '" readonly><br>\n  <label>Email:</label>\n  <input type="email" name="email" value="' + ($carDataEl.data('customerEmail') || '') + '" readonly><br>\n  <label>Car Title:</label>\n  <input type="text" name="car_title" value="' + ($carDataEl.data('carTitle') || '') + '" readonly><br>\n  <label>Price:</label>\n  <input type="text" name="car_price" value="' + ($carDataEl.data('carPrice') || '') + '" readonly><br>\n  <label>Payment Mode:</label>\n  <select name="payment_mode" id="payment_mode_select" required>\n    <option value="">Select</option>\n    <option value="credit_card">Credit Card</option>\n    <option value="debit_card">Debit Card</option>\n    <option value="net_banking">Net Banking</option>\n    <option value="upi">UPI</option>\n    <option value="neft">NEFT</option>\n    <option value="cash">Cash</option>\n  </select><br>\n  <div id="payment-extra-fields"></div>\n  <button type="submit" id="buy-now-btn">Buy Now</button>\n</form>\n';

              $formContainer.html(formHtml);

              // Autofill (also reads drupalSettings where needed)
              (function () {
                var dsLocal = ds;
                function read(key) {
                  var v = $carDataEl.data(key);
                  if (v !== undefined && v !== null && v !== '') { return v; }
                  if (dsLocal && dsLocal.carify_car_data && dsLocal.carify_car_data[key]) { return dsLocal.carify_car_data[key]; }
                  if (dsLocal && dsLocal.user) {
                    if (key === 'customerName' && (dsLocal.user.name)) { return dsLocal.user.name; }
                    if (key === 'customerEmail' && (dsLocal.user.mail || dsLocal.user.email)) { return dsLocal.user.mail || dsLocal.user.email; }
                    if (key === 'carTitle' && dsLocal.carify_car_data && dsLocal.carify_car_data.car_title) { return dsLocal.carify_car_data.car_title; }
                  }
                  return '';
                }
                var map = { 'name': 'customerName', 'email': 'customerEmail', 'car_title': 'carTitle', 'car_price': 'carPrice' };
                Object.keys(map).forEach(function (inputName) {
                  var key = map[inputName];
                  var val = read(key);
                  if (val !== '') { $formContainer.find('[name="' + inputName + '"]').val(val); }
                });
              })();

              // Payment mode dynamic fields
              $formContainer.on('change', '#payment_mode_select', function () {
                var mode = $(this).val();
                var extra = '';
                if (mode === 'credit_card' || mode === 'debit_card') {
                  extra = '<label>Card Holder Name:</label><input type="text" name="card_holder" required><br>' +
                    '<label>Card Number:</label><input type="text" name="card_number" required pattern="\\d{13,19}" maxlength="19"><br>' +
                    '<label>Expiry (MM/YY):</label><input type="text" name="card_expiry" required placeholder="MM/YY"><br>' +
                    '<label>CVV:</label><input type="text" name="card_cvv" required pattern="\\d{3,4}" maxlength="4"><br>';
                } else if (mode === 'net_banking') {
                  extra = '<label>Bank Name:</label><input type="text" name="bank_name" required><br>' +
                    '<label>Account No:</label><input type="text" name="account_no" required><br>';
                } else if (mode === 'neft') {
                  extra = '<label>Beneficiary Name:</label><input type="text" name="beneficiary_name" required><br>' +
                    '<label>Bank Name:</label><input type="text" name="bank_name_neft" required><br>' +
                    '<label>Account No:</label><input type="text" name="account_no_neft" required><br>' +
                    '<label>IFSC Code:</label><input type="text" name="ifsc" required pattern="[A-Za-z]{4}0[0-9A-Za-z]{6}"><br>';
                } else if (mode === 'upi') {
                  extra = '<label>UPI ID:</label><input type="text" name="upi_id" required placeholder="example@bank"><br>';
                } else if (mode === 'cash') {
                  extra = '<p>Cash payment selected. Prepare exact amount at pickup.</p>' +
                    '<label>Pickup Address:</label><input type="text" name="pickup_address"><br>';
                } else {
                  extra = '';
                }
                $formContainer.find('#payment-extra-fields').html(extra);
              });

              // Submit handler
              attachOnce($formContainer.find('#purchase-form'), 'carify-purchase-form', function ($formEl) {
                $formEl.on('submit', function (ev) {
                  ev.preventDefault();

                  var paymentMode = this.payment_mode ? this.payment_mode.value : '';
                  var purchaseData = {
                    car_id: $carDataEl.data('carId'),
                    car_title: $carDataEl.data('carTitle'),
                    car_price: $carDataEl.data('carPrice'),
                    seller_id: $carDataEl.data('sellerId'),
                    customer_id: $carDataEl.data('customerId'),
                    customer_name: $carDataEl.data('customerName'),
                    customer_email: $carDataEl.data('customerEmail'),
                    payment_mode: paymentMode,
                    purchase_time: new Date().toLocaleString()
                  };

                  // collect payment extra fields
                  var paymentDetails = {};
                  $formEl.find('#payment-extra-fields').find('input, select').each(function () {
                    var $i = $(this); var n = $i.attr('name'); if (n) { paymentDetails[n] = $i.val(); }
                  });
                  purchaseData.payment_details = paymentDetails;

                  // Require login
                  try {
                    if (ds && ds.user && ds.user.uid && parseInt(ds.user.uid) === 0) {
                      alert('You must be logged in to purchase'); return;
                    }
                  } catch (e) {}

                  // Candidate URLs
                  var candidates = [];
                  try {
                    if (ds && ds.path && ds.path.baseUrl) {
                      var baseUrl = ds.path.baseUrl.replace(/\/+$/,'');
                      candidates.push(baseUrl + '/carify/purchase');
                      candidates.push(baseUrl + '/index.php?q=carify/purchase');
                      candidates.push(baseUrl + '/?q=carify/purchase');
                    }
                  } catch (e) {}
                  candidates.push('/carify/purchase');
                  candidates.push('/index.php?q=carify/purchase');

                  // remove duplicates
                  candidates = candidates.filter(function (v, i, a) { return v && a.indexOf(v) === i; });

                  function attemptPost(i) {
                    if (i >= candidates.length) { alert('Purchase failed: no reachable endpoint'); return; }
                    var url = candidates[i];
                    $.ajax({ url: url, method: 'POST', data: purchaseData, dataType: 'json' })
                      .done(function (resp) {
                        if (resp && resp.success) {
                          $btn.remove(); $formContainer.empty(); alert('Purchase successful');
                        } else {
                          alert((resp && resp.message) ? resp.message : 'Purchase failed');
                        }
                      })
                      .fail(function (xhr) {
                        if (xhr && (xhr.status === 404 || xhr.status === 0)) { attemptPost(i+1); return; }
                        var msg = 'Purchase failed';
                        try {
                          if (xhr && xhr.responseJSON && xhr.responseJSON.message) { msg = xhr.responseJSON.message; }
                          else if (xhr && xhr.responseText) { msg = xhr.responseText; }
                        } catch (e) {}
                        alert(msg);
                      });
                  }

                  attemptPost(0);
                });
              });

            });
          });
        });
      }
    }
  };
})(Drupal, jQuery);

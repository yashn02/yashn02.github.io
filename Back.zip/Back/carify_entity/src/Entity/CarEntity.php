<?php

namespace Drupal\carify_entity\Entity;

use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\user\UserInterface;

/**
 * Defines the Car entity.
 *
 * @ContentEntityType(
 *   id = "car_entity",
 *   label = @Translation("Car"),
 *   handlers = {
 *     "list_builder" = "Drupal\Core\Entity\EntityListBuilder",
 *     "form" = {
 *       "add" = "Drupal\Core\Entity\ContentEntityForm",
 *       "edit" = "Drupal\Core\Entity\ContentEntityForm",
 *       "delete" = "Drupal\Core\Entity\ContentEntityDeleteForm"
 *     },
 *   },
 *   base_table = "car_entity",
 *   admin_permission = "administer car entity",
 *   entity_keys = {
 *     "id" = "id",
 *     "uuid" = "uuid",
 *     "label" = "title"
 *   },
 *   links = {
 *     "canonical" = "/car/{car_entity}",
 *     "add-form" = "/car/add",
 *     "edit-form" = "/car/{car_entity}/edit",
 *     "delete-form" = "/car/{car_entity}/delete",
 *     "collection" = "/carify"
 *   }
 * )
 */
class CarEntity extends ContentEntityBase {

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {
    $fields = parent::baseFieldDefinitions($entity_type);

    // ID and UUID are defined in parent.
    $fields['title'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Title'))
      ->setRequired(TRUE)
      ->setSettings([
        'max_length' => 255,
      ])
      ->setDisplayOptions('view', [
        'label' => 'hidden',
        'type' => 'string',
        'weight' => -5,
      ])
      ->setDisplayOptions('form', [
        'type' => 'string_textfield',
        'weight' => -5,
      ]);

    // Owner (user reference)
    
    $fields['user_id'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel(t('Authored by'))
      ->setSetting('target_type', 'user')
      ->setDefaultValueCallback('Drupal\carify_entity\Entity\CarEntity::getCurrentUserId')
      ->setDisplayOptions('view', ['label' => 'hidden', 'type' => 'author', 'weight' => 0])
      ->setDisplayOptions('form', ['type' => 'entity_reference_autocomplete', 'weight' => 0]);

    // Published status (moderation/publish).
    $fields['status'] = BaseFieldDefinition::create('boolean')
      ->setLabel(t('Published'))
      ->setDefaultValue(TRUE)
      ->setDisplayOptions('form', [
        'type' => 'boolean_checkbox',
        'weight' => 10,
      ]);

    // Price
    $fields['field_price'] = BaseFieldDefinition::create('decimal')
      ->setLabel(t('Price'))
      ->setSettings(['scale' => 2, 'precision' => 12])
      ->setDisplayOptions('view', ['label' => 'inline', 'type' => 'number_decimal', 'weight' => 5])
      ->setDisplayOptions('form', ['type' => 'number', 'weight' => 5]);

    // Year
    $fields['field_year'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('Year'))
      ->setSettings(['min' => 1900, 'max' => 2100])
      ->setDisplayOptions('view', ['label' => 'above', 'type' => 'number_integer', 'weight' => 6])
      ->setDisplayOptions('form', ['type' => 'number', 'weight' => 6]);

    // KMs driven
    $fields['field_kms_driven'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('KMs driven'))
      ->setDisplayOptions('form', ['type' => 'number', 'weight' => 7])
      ->setDisplayOptions('view', ['label' => 'above', 'type' => 'number_integer', 'weight' => 7]);

    // Mileage / Fuel type
    $fields['field_fuel_type'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Fuel type'))
      ->setSettings(['max_length' => 32])
      ->setDisplayOptions('form', ['type' => 'string_textfield', 'weight' => 8]);

    // Images field (image field type)
    $fields['field_images'] = BaseFieldDefinition::create('image')
      ->setLabel(t('Images'))
      ->setCardinality(5)  // allow up to 5 images
      ->setDisplayOptions('form', ['type' => 'image_image', 'weight' => 9])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    // Featured flag
    $fields['field_featured'] = BaseFieldDefinition::create('boolean')
      ->setLabel(t('Featured'))
      ->setDefaultValue(FALSE)
      ->setDisplayOptions('form', ['type' => 'boolean_checkbox', 'weight' => 11]);

    // Created, changed timestamps
    $fields['created'] = BaseFieldDefinition::create('created')
      ->setLabel(t('Created'));

    $fields['changed'] = BaseFieldDefinition::create('changed')
      ->setLabel(t('Changed'));

    return $fields;
  }
  public static function getCurrentUserId() {
  return [\Drupal::currentUser()->id()];
}

}

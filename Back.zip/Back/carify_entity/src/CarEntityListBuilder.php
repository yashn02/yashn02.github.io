<?php

namespace Drupal\carify_entity;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityListBuilder;

/**
 * Provides a list controller for car_entity entities.
 */
class CarEntityListBuilder extends EntityListBuilder {

  /**
   * {@inheritdoc}
   */
  public function buildHeader() {
    $header['title'] = $this->t('Title');
    $header['price'] = $this->t('Price');
    $header['owner'] = $this->t('Owner');
    $header['status'] = $this->t('Published');
    $header['created'] = $this->t('Created');
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    /** @var \Drupal\carify_entity\Entity\CarEntity $entity */
    $row['title'] = $entity->label();
    $row['price'] = $entity->get('field_price')->value ?? '';
    $row['owner'] = $entity->getOwnerId();
    $row['status'] = $entity->get('status')->value ? $this->t('Yes') : $this->t('No');
    $row['created'] = \Drupal::service('date.formatter')->format($entity->getCreatedTime(), 'short');
    return $row + parent::buildRow($entity);
  }
}

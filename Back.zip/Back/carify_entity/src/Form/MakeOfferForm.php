<?php

namespace Drupal\carify_entity\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Database\Connection;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Form for submitting an offer for a specific car.
 */
class MakeOfferForm extends FormBase {

  /**
   * The database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    $instance = new static();
    $instance->database = $container->get('database');
    return $instance;
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'carify_make_offer_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, $car_id = NULL) {
    if (!$car_id) {
      return ['#markup' => $this->t('Invalid car context.')];
    }

    $form['car_id'] = [
      '#type' => 'hidden',
      '#value' => $car_id,
    ];

    $form['offer_price'] = [
      '#type' => 'number',
      '#title' => $this->t('Your Offer Price (₹)'),
      '#required' => TRUE,
      '#min' => 1000,
      '#step' => 1000,
    ];

    $form['message'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Message to seller'),
      '#required' => FALSE,
      '#rows' => 3,
    ];

    $form['name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Your Name'),
      '#required' => TRUE,
    ];

    $form['email'] = [
      '#type' => 'email',
      '#title' => $this->t('Your Email'),
      '#required' => TRUE,
    ];

    $form['actions'] = ['#type' => 'actions'];
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Submit Offer'),
      '#button_type' => 'primary',
    ];

    $form['#attributes']['class'][] = 'carify-make-offer-form';

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    if ($form_state->getValue('offer_price') <= 0) {
      $form_state->setErrorByName('offer_price', $this->t('Please enter a valid price.'));
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $values = $form_state->getValues();
    $this->database->insert('carify_offers')
      ->fields([
        'car_id' => $values['car_id'],
        'name' => $values['name'],
        'email' => $values['email'],
        'offer_price' => $values['offer_price'],
        'message' => $values['message'],
        'created' => \Drupal::time()->getRequestTime(),
      ])
      ->execute();

    $this->messenger()->addStatus($this->t('Your offer has been sent successfully! The seller will contact you soon.'));
  }
}

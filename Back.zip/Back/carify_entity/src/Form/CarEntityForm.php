<?php

namespace Drupal\carify_entity\Form;

use Drupal\Core\Entity\ContentEntityForm;
use Drupal\Core\Form\FormStateInterface;

/**
 * Form controller for the car_entity add/edit forms.
 */
class CarEntityForm extends ContentEntityForm {

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    /* @var $entity \Drupal\carify_entity\Entity\CarEntity */
    $form = parent::buildForm($form, $form_state);

    // Optionally add description or warnings in form.
    if ($this->entity->isNew()) {
      $form['#title'] = $this->t('Add a Car - Carify');
      $form['description'] = [
        '#type' => 'item',
        '#markup' => $this->t('<em>Fill all required fields carefully. Uploaded images should be in JPG/PNG and appropriate size. For used/new selection use taxonomy or the description below.</em>'),
      ];
    }

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function save(array $form, FormStateInterface $form_state) {
    $entity = $this->entity;
    $status = $entity->save();

    if ($status == SAVED_NEW) {
      $this->messenger()->addMessage($this->t('Car %label has been created.', ['%label' => $entity->label()]));
    }
    else {
      $this->messenger()->addMessage($this->t('Car %label has been updated.', ['%label' => $entity->label()]));
    }

    $form_state->setRedirect('carify_entity.view', ['car_entity' => $entity->id()]);
  }
}

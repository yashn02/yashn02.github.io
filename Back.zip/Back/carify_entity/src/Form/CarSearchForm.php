<?php

namespace Drupal\carify_entity\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Database\Connection;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Url;

/**
 * Simple SQL search form for cars.
 */
class CarSearchForm extends FormBase {

  /**
   * The database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    $instance = new static();
    $instance->database = $container->get('database');
    return $instance;
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'carify_car_search_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['keywords'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Search Cars'),
      '#attributes' => [
        'placeholder' => $this->t('Search by make or model...'),
      ],
    ];

    $form['actions'] = ['#type' => 'actions'];
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Search'),
      '#button_type' => 'primary',
    ];

    // If user has submitted a search, display results below.
    if ($form_state->get('results')) {
      $form['results'] = [
        '#theme' => 'item_list',
        '#items' => $form_state->get('results'),
        '#attributes' => ['class' => ['carify-search-results']],
      ];
    }

    $form['#attributes']['class'][] = 'carify-car-search-form';

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $keyword = trim($form_state->getValue('keywords'));
    $results = [];

    if ($keyword !== '') {
      // Query car_entity table for matches.
      $query = $this->database->select('car_entity', 'c')
        ->fields('c', ['id', 'title', 'field_price', 'field_year'])
        ->condition('status', 1);

      // Search by make/model within title or fuel_type field.
      $group = $query->orConditionGroup()
        ->condition('title', '%' . $this->database->escapeLike($keyword) . '%', 'LIKE')
        ->condition('field_fuel_type', '%' . $this->database->escapeLike($keyword) . '%', 'LIKE');
      $query->condition($group);

      $query->range(0, 10);
      $query->orderBy('created', 'DESC');

      $cars = $query->execute()->fetchAll();

      if ($cars) {
        foreach ($cars as $car) {
          $url = Url::fromRoute('carify_entity.view', ['car_entity' => $car->id])->toString();
          $results[] = [
            '#markup' => '<div class="car-card"><a href="' . $url . '"><strong>' . $car->title . '</strong></a><br>₹' . $car->field_price . ' • ' . $car->field_year . '</div>',
          ];
        }
      }
      else {
        $results[] = ['#markup' => $this->t('No cars found for your search.')];
      }
    }
    else {
      $results[] = ['#markup' => $this->t('Please enter a keyword to search.')];
    }

    $form_state->set('results', $results);
    $form_state->setRebuild(TRUE);
  }
}

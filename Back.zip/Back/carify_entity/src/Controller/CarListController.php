<?php

namespace Drupal\carify_module\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\node\Entity\Node;

class CarListController extends ControllerBase {

  public function carListPage() {
    $storage = \Drupal::entityTypeManager()->getStorage('node');
    $view_builder = \Drupal::entityTypeManager()->getViewBuilder('node');

    // Load published car_entity nodes.
    $nids = $storage->getQuery()
      ->condition('type', 'car_entity')
      ->condition('status', 1)
      ->sort('created', 'DESC')
      ->execute();

    $nodes = $storage->loadMultiple($nids);

    $cars = [];
    foreach ($nodes as $node) {
      $cars[] = $view_builder->view($node, 'teaser');
    }

    return [
      '#theme' => 'carify_car_list',
      '#cars' => $cars,
    ];
  }
}
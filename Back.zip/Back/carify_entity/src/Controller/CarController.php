<?php

namespace Drupal\carify_entity\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Connection;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Url;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Drupal\Core\Entity\EntityTypeManagerInterface;

/**
 * Returns responses for Car entity routes.
 */
class CarController extends ControllerBase {

  /**
   * Database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * Entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * Dependency injection.
   */
  public static function create(ContainerInterface $container) {
    $instance = new static();
    $instance->database = $container->get('database');
    $instance->entityTypeManager = $container->get('entity_type.manager');
    return $instance;
  }

  /**
   * Lists all cars at /carify with pagination (10 per page).
   */
  public function list() {
    // Load car entities so field data (images) are available.
    $storage = $this->entityTypeManager->getStorage('car_entity');

    // Pagination limit.
    $limit = 10;

    // Base query for counting total published cars.
    $count_query = \Drupal::entityQuery('car_entity')
      ->accessCheck(TRUE)
      ->condition('status', 1);

    $total = $count_query->count()->execute();

    // Initialize pager and determine current page.
    // pager_default_initialize sets up Drupal's pager system.
    pager_default_initialize($total, $limit);
    $current_page = pager_find_page();
    $offset = $current_page * $limit;

    // Entity queries must explicitly set access checking.
    $query = \Drupal::entityQuery('car_entity')
      ->accessCheck(TRUE)
      ->condition('status', 1)
      ->sort('created', 'DESC')
      ->range($offset, $limit);

    $ids = $query->execute();
    $entities = $storage->loadMultiple($ids);

    $cars = [];

    foreach ($entities as $entity) {
      // Prepare image render array (uses field display settings or an image style).
      $image_render = NULL;
      if ($entity->hasField('field_images') && !$entity->get('field_images')->isEmpty()) {
        // Render the field with a simple image style (thumbnail) for list.
        $image_render = $entity->get('field_images')->view(['label' => 'hidden', 'type' => 'image_style', 'settings' => ['image_style' => 'thumbnail']]);
      }

      // Wrap scalar values in render arrays so the parent array is fully renderable.
      $cars[] = [
        'title' => ['#markup' => $entity->label()],
        'price' => ['#markup' => $entity->get('field_price')->value],
        'year' => ['#markup' => $entity->get('field_year')->value],
        // Provide URL as a string so it can be used in an href attribute in Twig.
        'url' => Url::fromRoute('carify_entity.view', ['car_entity' => $entity->id()])->toString(),
        'image' => $image_render ?: [],
      ];
    }

    return [
      '#theme' => 'carify_car_list',
      '#cars' => $cars,
      // Provide pager render element for the template.
      '#pager' => ['#type' => 'pager'],
      // Provide a view-all URL so themes can render a "View all cars" button.
      '#view_all_url' => Url::fromRoute('carify_entity.list_all')->toString(),
      '#cache' => ['tags' => ['car_entity_list']],
      '#attached' => [
        'library' => [
          'carify/global-styling',
        ],
      ],
    ];
  }

  /**
   * Displays a single car at /car/{car_entity}.
   */
  public function view($car_entity) {
    // Load the car entity so fields (including images) are available.
    $entity = $this->entityTypeManager->getStorage('car_entity')->load($car_entity);

    // If not found, 404.
    if (!$entity) {
      throw new NotFoundHttpException();
    }

    // Render images (use a larger image style for detail page).
    $images_render = NULL;
    if ($entity->hasField('field_images') && !$entity->get('field_images')->isEmpty()) {
      $images_render = $entity->get('field_images')->view(['label' => 'hidden', 'type' => 'image_style', 'settings' => ['image_style' => 'large']]);
    }

    // Prepare a simple data object for the Twig template (keeps existing template keys).
    $car = new \stdClass();
    $car->title = $entity->label();
    $car->field_price = $entity->get('field_price')->value;
    $car->field_year = $entity->get('field_year')->value;
    $car->field_description = $entity->hasField('field_description') ? $entity->get('field_description')->value : '';

    // Permissions: show edit/delete only to owner or users with the relevant permissions.
    $current_user = $this->currentUser();
    $uid = NULL;
    if ($entity->hasField('uid')) {
      $uid = $entity->get('uid')->target_id;
    }

    $can_edit = FALSE;
    $can_delete = FALSE;

    if ($current_user->hasPermission('carify_entity:edit_any')) {
      $can_edit = TRUE;
    }
    elseif ($current_user->hasPermission('carify_entity:edit_own') && $uid !== NULL && $uid == $current_user->id()) {
      $can_edit = TRUE;
    }

    if ($current_user->hasPermission('carify_entity:delete_any')) {
      $can_delete = TRUE;
    }
    elseif ($current_user->hasPermission('carify_entity:delete_own') && $uid !== NULL && $uid == $current_user->id()) {
      $can_delete = TRUE;
    }

    // Build edit/delete URLs.
    $edit_url = $can_edit ? Url::fromRoute('carify_entity.edit', ['car_entity' => $entity->id()])->toString() : NULL;
    $delete_url = $can_delete ? Url::fromRoute('carify_entity.delete', ['car_entity' => $entity->id()])->toString() : NULL;

    return [
      '#theme' => 'carify_car_detail',
      '#car' => $car,
      '#images' => $images_render,
      '#edit_url' => $edit_url,
      '#delete_url' => $delete_url,
      '#show_edit' => (bool) $can_edit,
      '#show_delete' => (bool) $can_delete,
      '#cache' => ['tags' => $entity->getCacheTags()],
      '#attached' => [
        'library' => [
          'carify/global-styling',
        ],
      ],
    ];
  }

  /**
   * Show the add form (handled by the entity form) — route uses the entity form directly.
   */
  public function add() {
    // Redirect to the entity form route which will render the add form and handle access.
    return $this->redirect('carify_entity.add');
  }

  /**
   * The edit route is handled by the entity form; this controller method is not used for rendering.
   * Keep a small helper in case other code calls it (redirect to the entity form route).
   */
  public function edit($car_entity) {
    return $this->redirect('carify_entity.edit', ['car_entity' => $car_entity]);
  }

  /**
   * Soft-delete: unpublish the car by setting status to 0 when delete route is called.
   */
  public function delete($car_entity) {
    $storage = $this->entityTypeManager->getStorage('car_entity');
    $entity = $storage->load($car_entity);
    if (!$entity) {
      throw new NotFoundHttpException();
    }

    $current_user = $this->currentUser();
    $uid = NULL;
    if ($entity->hasField('uid')) {
      $uid = $entity->get('uid')->target_id;
    }

    if (!(
      $current_user->hasPermission('carify_entity:delete_any') ||
      ($current_user->hasPermission('carify_entity:delete_own') && $uid !== NULL && $uid == $current_user->id())
    )) {
      throw new \Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException();
    }

    // Unpublish instead of permanent delete.
    if ($entity->hasField('status')) {
      $entity->set('status', 0);
    }
    else {
      // Try setPublished(FALSE) if available.
      if (method_exists($entity, 'setPublished')) {
        $entity->setPublished(FALSE);
      }
    }
    $entity->save();

    \Drupal::messenger()->addStatus($this->t('The car has been unpublished.'));

    return $this->redirect('carify_entity.list');
  }

  /**
   * Lists all cars without filtering (for view-all page) with pagination.
   */
  public function listAll() {
    $storage = $this->entityTypeManager->getStorage('car_entity');
    $limit = 10;

    // Count all published cars (same as list) but allow viewing unpublished only if permission granted.
    $query_count = \Drupal::entityQuery('car_entity')->accessCheck(TRUE)->condition('status', 1);
    $total = $query_count->count()->execute();

    pager_default_initialize($total, $limit);
    $current_page = pager_find_page();
    $offset = $current_page * $limit;

    $query = \Drupal::entityQuery('car_entity')
      ->accessCheck(TRUE)
      ->condition('status', 1)
      ->sort('created', 'DESC')
      ->range($offset, $limit);

    $ids = $query->execute();
    $entities = $storage->loadMultiple($ids);

    $cars = [];
    foreach ($entities as $entity) {
      $image_render = NULL;
      if ($entity->hasField('field_images') && !$entity->get('field_images')->isEmpty()) {
        $image_render = $entity->get('field_images')->view(['label' => 'hidden', 'type' => 'image_style', 'settings' => ['image_style' => 'thumbnail']]);
      }
      $cars[] = [
        'title' => ['#markup' => $entity->label()],
        'price' => ['#markup' => $entity->get('field_price')->value],
        'year' => ['#markup' => $entity->get('field_year')->value],
        'url' => Url::fromRoute('carify_entity.view', ['car_entity' => $entity->id()])->toString(),
        'image' => $image_render ?: [],
      ];
    }

    return [
      '#theme' => 'carify_car_list',
      '#cars' => $cars,
      '#pager' => ['#type' => 'pager'],
      '#cache' => ['tags' => ['car_entity_list']],
      '#attached' => [ 'library' => ['carify/global-styling'] ],
    ];
  }

  /**
   * Handle purchase POST request: mark car as unpublished automatically on purchase.
   */
  public function purchase() {
    $request = \Drupal::request();
    $data = $request->request->all();

    if (empty($data['car_id'])) {
      return new \Symfony\Component\HttpFoundation\JsonResponse(['success' => FALSE, 'message' => 'Missing car id'], 400);
    }

    $car_id = (int) $data['car_id'];
    $storage = $this->entityTypeManager->getStorage('car_entity');
    $entity = $storage->load($car_id);
    if (!$entity) {
      return new \Symfony\Component\HttpFoundation\JsonResponse(['success' => FALSE, 'message' => 'Car not found'], 404);
    }

    // Perform basic permission check: user must be logged in.
    $current_user = $this->currentUser();
    if ($current_user->isAnonymous()) {
      return new \Symfony\Component\HttpFoundation\JsonResponse(['success' => FALSE, 'message' => 'Authentication required'], 403);
    }

    // Here you would process payment details / record the purchase in DB. For now, mark car unpublished.
    if ($entity->hasField('status')) {
      $entity->set('status', 0);
    }
    elseif (method_exists($entity, 'setPublished')) {
      $entity->setPublished(FALSE);
    }
    $entity->save();

    // Optionally record purchase in separate table.
    try {
      $this->database->insert('carify_purchases')->fields([
        'car_id' => $car_id,
        'buyer_uid' => $current_user->id(),
        'data' => serialize($data),
        'created' => \Drupal::time()->getRequestTime(),
      ])->execute();
    } catch (\Exception $e) {
      // ignore if table missing; still succeed unpublish.
    }

    return new \Symfony\Component\HttpFoundation\JsonResponse(['success' => TRUE, 'message' => 'Purchase recorded and car unpublished']);
  }

}

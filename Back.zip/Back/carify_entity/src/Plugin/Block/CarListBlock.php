<?php

namespace Drupal\carify_entity\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Cache\Cache;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Plugin\PluginBase;
use Drupal\Core\Plugin\ContextAwarePluginInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;

/**
 * Provides a 'Car list' block.
 *
 * @Block(
 *   id = "carify_car_list_block",
 *   admin_label = @Translation("Carify - Car list"),
 *   category = @Translation("Carify")
 * )
 */
class CarListBlock extends BlockBase implements ContainerFactoryPluginInterface {

  /** @var \Drupal\Core\Entity\EntityTypeManagerInterface */
  protected $entityTypeManager;

  public function __construct(array $configuration, $plugin_id, $plugin_definition, EntityTypeManagerInterface $entity_type_manager) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->entityTypeManager = $entity_type_manager;
  }

  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager')
    );
  }

  public function build() {
    $storage = $this->entityTypeManager->getStorage('car_entity');
    $limit = 10;

    $count_query = \Drupal::entityQuery('car_entity')
      ->accessCheck(TRUE)
      ->condition('status', 1);

    $total = $count_query->count()->execute();

    pager_default_initialize($total, $limit);
    $current_page = pager_find_page();
    $offset = $current_page * $limit;

    $query = \Drupal::entityQuery('car_entity')
      ->accessCheck(TRUE)
      ->condition('status', 1)
      ->sort('created', 'DESC')
      ->range($offset, $limit);

    $ids = $query->execute();
    $entities = $storage->loadMultiple($ids);

    $cars = [];
    foreach ($entities as $entity) {
      $image_render = [];
      if ($entity->hasField('field_images') && !$entity->get('field_images')->isEmpty()) {
        $image_render = $entity->get('field_images')->view(['label' => 'hidden', 'type' => 'image_style', 'settings' => ['image_style' => 'thumbnail']]);
      }
      $cars[] = [
        'title' => ['#markup' => $entity->label()],
        'price' => ['#markup' => $entity->get('field_price')->value],
        'year' => ['#markup' => $entity->get('field_year')->value],
        'url' => \Drupal\Core\Url::fromRoute('carify_entity.view', ['car_entity' => $entity->id()])->toString(),
        'image' => $image_render ?: [],
      ];
    }

    $build = [
      '#theme' => 'carify_car_list',
      '#cars' => $cars,
      '#pager' => ['#type' => 'pager'],
      '#view_all_url' => \Drupal\Core\Url::fromRoute('carify_entity.list_all')->toString(),
      '#attached' => [ 'library' => ['carify/global-styling'] ],
      '#cache' => [ 'tags' => ['car_entity_list'] ],
    ];

    return $build;
  }

  public function getCacheTags() {
    return Cache::mergeTags(parent::getCacheTags(), ['car_entity_list']);
  }
}

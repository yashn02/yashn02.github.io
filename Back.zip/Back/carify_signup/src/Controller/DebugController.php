<?php

namespace Drupal\carify_signup\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;

class DebugController extends ControllerBase {
  /**
   * Return a drupalSettings-like JSON payload for debugging.
   */
  public function debug(Request $request) {
    $current_user = \Drupal::currentUser();
    $user_info = [
      'uid' => (int) $current_user->id(),
      'name' => $current_user->isAuthenticated() ? $current_user->getAccountName() : '',
      'mail' => '',
      'roles' => array_values($current_user->getRoles()),
    ];

    // Detect car id from ?car= or path /car/{id}
    $car_id = $request->query->get('car');
    if (!$car_id) {
      $path = $request->getPathInfo();
      if (preg_match('#/car/(\d+)#', $path, $m)) { $car_id = $m[1]; }
    }

    $car_data = NULL;
    if ($car_id) {
      // Try node
      $node = \Drupal::entityTypeManager()->getStorage('node')->load($car_id);
      if ($node) {
        $car_data = [
          'car_id' => $node->id(),
          'car_title' => $node->label(),
          'car_price' => ($node->hasField('field_price') ? $node->get('field_price')->value : ''),
          'seller_id' => method_exists($node, 'getOwnerId') ? (int) $node->getOwnerId() : ($node->hasField('uid') ? (int) $node->get('uid')->target_id : 0),
        ];
      }
      else {
        // Try custom car_entity
        if (\Drupal::entityTypeManager()->hasDefinition('car_entity')) {
          $storage = \Drupal::entityTypeManager()->getStorage('car_entity');
          $car = $storage->load($car_id);
          if ($car) {
            $car_data = [
              'car_id' => $car->id(),
              'car_title' => $car->label(),
              'car_price' => ($car->hasField('field_price') ? $car->get('field_price')->value : ''),
              'seller_id' => method_exists($car, 'getOwnerId') ? (int) $car->getOwnerId() : ($car->hasField('user_id') ? (int) $car->get('user_id')->target_id : 0),
            ];
          }
        }
      }
    }

    return new JsonResponse([
      'drupalSettings_user' => $user_info,
      'carify_car_data' => $car_data,
      'path' => $request->getPathInfo(),
    ]);
  }
}

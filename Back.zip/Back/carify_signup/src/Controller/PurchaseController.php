<?php
namespace Drupal\carify_signup\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;

class PurchaseController extends ControllerBase {
  public function purchase(Request $request) {
    $data = $request->request->all();

    // Accept missing car_id or customer_id and store NULL instead of rejecting the request.
    $car_id_val = (isset($data['car_id']) && $data['car_id'] !== '') ? (int) $data['car_id'] : NULL;
    $customer_id_val = (isset($data['customer_id']) && $data['customer_id'] !== '') ? (int) $data['customer_id'] : NULL;

    // Ensure car_purchase table exists; if not, create it (temporary convenience)
    try {
      $schema = \Drupal::database()->schema();
      if (!$schema->tableExists('car_purchase')) {
        $schema->createTable('car_purchase', [
          'fields' => [
            'id' => ['type' => 'serial', 'not null' => TRUE],
            'car_id' => ['type' => 'int', 'not null' => FALSE],
            'car_title' => ['type' => 'varchar', 'length' => 255, 'not null' => FALSE],
            'car_price' => ['type' => 'varchar', 'length' => 64, 'not null' => FALSE],
            'seller_id' => ['type' => 'int', 'not null' => FALSE],
            'customer_id' => ['type' => 'int', 'not null' => FALSE],
            'customer_name' => ['type' => 'varchar', 'length' => 255, 'not null' => FALSE],
            'customer_email' => ['type' => 'varchar', 'length' => 255, 'not null' => FALSE],
            'customer_address' => ['type' => 'text', 'size' => 'big', 'not null' => FALSE],
            'customer_phone' => ['type' => 'varchar', 'length' => 64, 'not null' => FALSE],
            'payment_mode' => ['type' => 'varchar', 'length' => 64, 'not null' => FALSE],
            'payment_details' => ['type' => 'text', 'size' => 'big', 'not null' => FALSE],
            'purchase_time' => ['type' => 'varchar', 'length' => 64, 'not null' => FALSE],
          ],
          'primary key' => ['id'],
        ]);
      }
    }
    catch (\Exception $e) {
      return new JsonResponse(['success' => FALSE, 'message' => 'Failed to prepare purchase storage: ' . $e->getMessage()], 500);
    }

    $fields = [
      'car_id' => $car_id_val,
      'car_title' => (isset($data['car_title']) && $data['car_title'] !== '') ? $data['car_title'] : NULL,
      'car_price' => (isset($data['car_price']) && $data['car_price'] !== '') ? $data['car_price'] : NULL,
      'seller_id' => (isset($data['seller_id']) && $data['seller_id'] !== '') ? (int) $data['seller_id'] : NULL,
      'customer_id' => $customer_id_val,
      'customer_name' => (isset($data['customer_name']) && $data['customer_name'] !== '') ? $data['customer_name'] : NULL,
      'customer_email' => (isset($data['customer_email']) && $data['customer_email'] !== '') ? $data['customer_email'] : NULL,
      'customer_address' => (isset($data['customer_address']) && $data['customer_address'] !== '') ? $data['customer_address'] : NULL,
      'customer_phone' => (isset($data['customer_phone']) && $data['customer_phone'] !== '') ? $data['customer_phone'] : NULL,
      'payment_mode' => (isset($data['payment_mode']) && $data['payment_mode'] !== '') ? $data['payment_mode'] : NULL,
      'payment_details' => isset($data['payment_details']) ? (is_array($data['payment_details']) ? json_encode($data['payment_details']) : $data['payment_details']) : NULL,
      'purchase_time' => date('Y-m-d H:i:s'),
    ];

    // Insert into car_purchase table
    try {
      $insert = \Drupal::database()->insert('car_purchase')
        ->fields($fields)
        ->execute();
    }
    catch (\Exception $e) {
      return new JsonResponse(['success' => FALSE, 'message' => 'Database insert failed: ' . $e->getMessage()], 500);
    }

    // Attempt to unpublish entity/car if possible (best-effort)
    try {
      if ($car_id_val) {
        if (\Drupal::entityTypeManager()->hasDefinition('car_entity')) {
          $storage = \Drupal::entityTypeManager()->getStorage('car_entity');
          $car = $storage->load($car_id_val);
          if ($car && $car->hasField('status')) { $car->set('status', 0); $car->save(); }
        }
        else {
          $node_storage = \Drupal::entityTypeManager()->getStorage('node');
          $node = $node_storage->load($car_id_val);
          if ($node && $node->hasField('status')) { $node->set('status', 0); $node->save(); }
        }
      }
    }
    catch (\Throwable $e) {
      // ignore
    }

    return new JsonResponse(['success' => TRUE, 'id' => $insert]);
  }
}

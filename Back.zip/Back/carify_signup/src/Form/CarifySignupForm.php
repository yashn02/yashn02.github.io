<?php
namespace Drupal\carify_signup\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\user\Entity\User;

class CarifySignupForm extends FormBase {

  public function getFormId() {
    return 'carify_signup_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['role'] = [
      '#type' => 'radios',
      '#title' => $this->t('Role'),
      '#options' => ['seller' => $this->t('Seller'), 'customer' => $this->t('Customer')],
      '#required' => TRUE,
    ];
    $form['address'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Address'),
      '#required' => TRUE,
    ];
    $form['phone'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Phone Number'),
      '#required' => TRUE,
    ];
    $form['aadhaar'] = [
      '#type' => 'managed_file',
      '#title' => $this->t('Aadhaar Upload'),
      '#upload_location' => 'public://aadhaar/',
      '#required' => TRUE,
    ];
    $form['name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Username'),
      '#required' => TRUE,
    ];
    $form['mail'] = [
      '#type' => 'email',
      '#title' => $this->t('Email'),
      '#required' => TRUE,
    ];
    $form['pass'] = [
      '#type' => 'password',
      '#title' => $this->t('Password'),
      '#required' => TRUE,
    ];
    $form['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Sign Up'),
    ];
    return $form;
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $user = User::create([
      'name' => $form_state->getValue('name'),
      'mail' => $form_state->getValue('mail'),
      'pass' => $form_state->getValue('pass'),
      'status' => 1,
    ]);
    $user->addRole($form_state->getValue('role'));
    $user->set('field_address', $form_state->getValue('address'));
    $user->set('field_phone', $form_state->getValue('phone'));
    $user->set('field_aadhaar', $form_state->getValue('aadhaar'));
    $user->save();
    \Drupal::messenger()->addMessage($this->t('Signup successful. You can now log in.'));
    $form_state->setRedirect('user.login');
  }
}
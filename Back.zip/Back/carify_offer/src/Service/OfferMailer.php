<?php

namespace Drupal\carify_offer\Service;

class OfferMailer {

  protected $mailManager;

  public function __construct($mail_manager) {
    $this->mailManager = $mail_manager;
  }

  /**
   * Send mail using core mail manager.
   */
  public function send($module, $key, $to, $langcode, array $params = []) {
    return $this->mailManager->mail($module, $key, $to, $langcode, $params, NULL, TRUE);
  }
}

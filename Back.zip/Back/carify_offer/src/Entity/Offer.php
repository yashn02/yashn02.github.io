<?php

namespace Drupal\carify_offer\Entity;

use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Field\BaseFieldDefinition;

/**
 * Defines the Offer entity.
 *
 * @ContentEntityType(
 *   id = "offer",
 *   label = @Translation("Offer"),
 *   handlers = {
 *     "list_builder" = "Drupal\Core\Entity\EntityListBuilder",
 *     "form" = {
 *       "default" = "Drupal\Core\Entity\ContentEntityForm",
 *     },
 *   },
 *   base_table = "offer",
 *   admin_permission = "administer offer",
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "title",
 *     "uuid" = "uuid"
 *   },
 *   links = {
 *     "canonical" = "/offer/{offer}"
 *   }
 * )
 */
class Offer extends ContentEntityBase {

  public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {
    $fields = parent::baseFieldDefinitions($entity_type);

    $fields['title'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Title'))
      ->setSettings(['max_length' => 255])
      ->setDisplayOptions('view', ['label' => 'hidden']);

    $fields['offer_price'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('Offer price'))
      ->setRequired(TRUE);

    $fields['offer_message'] = BaseFieldDefinition::create('text_long')
      ->setLabel(t('Offer message'));

    $fields['car_id'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel(t('Car'))
      ->setSetting('target_type', 'car_entity')
      ->setRequired(TRUE);

    $fields['uid'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel(t('Customer'))
      ->setSetting('target_type', 'user')
      ->setDefaultValueCallback('Drupal\carify_offer\Entity\Offer::getCurrentUserId');

    $fields['seller_id'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel(t('Seller'))
      ->setSetting('target_type', 'user');

    $fields['offer_status'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel(t('Offer status'))
      ->setSetting('target_type', 'taxonomy_term')
      ->setCardinality(1);

    $fields['parent_offer'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel(t('Parent offer'))
      ->setSetting('target_type', 'offer');

    $fields['accepted_time'] = BaseFieldDefinition::create('timestamp')
      ->setLabel(t('Accepted time'));

    $fields['created'] = BaseFieldDefinition::create('created')
      ->setLabel(t('Created'));

    $fields['changed'] = BaseFieldDefinition::create('changed')
      ->setLabel(t('Changed'));

    return $fields;
  }

  public static function getCurrentUserId() {
    return [\Drupal::currentUser()->id()];
  }
}

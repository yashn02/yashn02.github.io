<?php

namespace Drupal\carify_offer\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Access\AccessResult;
use Drupal\Core\Url;

/**
 * Provides an 'Offers in header' block.
 *
 * @Block(
 *   id = "carify_offer_header_block",
 *   admin_label = @Translation("Offers in header"),
 * )
 */
class OfferHeaderBlock extends BlockBase {

  public function build() {
    $account = \Drupal::currentUser();
    if ($account->isAnonymous()) {
      return [];
    }

    $uid = $account->id();
    $count = 0;
    $url = NULL;

    if (in_array('seller', $account->getRoles())) {
      $query = \Drupal::entityQuery('offer')->accessCheck(TRUE)->condition('seller_id', $uid);
      $ids = $query->execute();
      $count = $ids ? count($ids) : 0;
      $url = Url::fromRoute('carify_offer.seller_offers');
    }
    elseif (in_array('customer', $account->getRoles())) {
      $query = \Drupal::entityQuery('offer')->accessCheck(TRUE)->condition('uid', $uid);
      $ids = $query->execute();
      $count = $ids ? count($ids) : 0;
      $url = Url::fromRoute('carify_offer.customer_offers');
    }
    else {
      return [];
    }

    // Render as a link render array so Twig can theme it properly.
    return [
      '#type' => 'link',
      '#title' => $this->t('@count offers', ['@count' => $count]),
      '#url' => $url,
      '#attributes' => ['class' => ['header-offers']],
      '#cache' => ['max-age' => 0],
    ];
  }

  protected function blockAccess(AccountInterface $account) {
    return AccessResult::allowedIf(!$account->isAnonymous());
  }
}

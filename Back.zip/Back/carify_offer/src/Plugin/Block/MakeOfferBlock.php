<?php

namespace Drupal\carify_offer\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Access\AccessResult;

/**
 * Provides 'Make Offer' block.
 *
 * @Block(
 *   id = "carify_make_offer_block",
 *   admin_label = @Translation("Make Offer (Carify)"),
 * )
 */
class MakeOfferBlock extends BlockBase {

  public function build() {
    $route = \Drupal::routeMatch();
    $car = $route->getParameter('car_entity');
    if (!$car) {
      return [];
    }

    // If the route provided an ID (string/int) instead of the entity object,
    // try to load the car entity so we can call ->get() on it safely.
    if (is_scalar($car)) {
      $car = \Drupal::entityTypeManager()->getStorage('car_entity')->load($car);
    }

    // If we still don't have an entity, bail out.
    if (!$car || !($car instanceof \Drupal\Core\Entity\ContentEntityInterface)) {
      return [];
    }

    $current_user = \Drupal::currentUser();
    if ($current_user->isAnonymous()) {
      return ['#markup' => $this->t('Please log in to make an offer.')];
    }

    // Only customers should see the form.
    if (!in_array('customer', $current_user->getRoles())) {
      return ['#markup' => $this->t('Only customers may make offers.')];
    }

    // Do not allow owner to make offer.
    $owner_id = $car->get('user_id')->target_id ?? NULL;
    if ($owner_id && $owner_id == $current_user->id()) {
      return ['#markup' => $this->t('You are the owner of this car.')];
    }

    $form = \Drupal::formBuilder()->getForm('Drupal\carify_offer\Form\OfferForm', $car);

    return [
      '#theme' => 'make_offer_block',
      '#car' => $car,
      '#offer_form' => $form,
      '#cache' => ['max-age' => 0],
    ];
  }

  protected function blockAccess(AccountInterface $account) {
    if ($account->isAnonymous()) {
      return AccessResult::forbidden();
    }
    return AccessResult::allowed();
  }
}

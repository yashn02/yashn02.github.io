<?php

namespace Drupal\carify_offer\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\message\Entity\Message;

/**
 * Offer submission form for customers.
 */
class OfferForm extends FormBase {

  public function getFormId() {
    return 'carify_offer_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state, $car = NULL) {
    if (!$car) {
      return ['#markup' => $this->t('No car selected.')];
    }

    $current_user = \Drupal::currentUser();
    $uid = $current_user->id();

    // Check existing outstanding offers
    $existing = \Drupal::entityTypeManager()->getStorage('offer')->loadByProperties([
      'car_id' => $car->id(),
      'uid' => $uid,
    ]);
    foreach ($existing as $o) {
      $terms = $o->get('offer_status')->referencedEntities();
      foreach ($terms as $t) {
        $name = $t->getName();
        if ($name !== 'Accept' && $name !== 'Reject') {
          return ['#markup' => $this->t("Waiting for seller's decision.")];
        }
      }
    }

    // Count rejected offers for this user+car
    $rejected = 0;
    foreach ($existing as $o) {
      $terms = $o->get('offer_status')->referencedEntities();
      foreach ($terms as $t) {
        if ($t->getName() === 'Reject') {
          $rejected++;
        }
      }
    }
    if ($rejected >= 5) {
      return ['#markup' => $this->t('You can no longer send offers for this car.')];
    }

    $form['car_id'] = [
      '#type' => 'value',
      '#value' => $car->id(),
    ];

    $form['offer_price'] = [
      '#type' => 'number',
      '#title' => $this->t('Offer price'),
      '#required' => TRUE,
      '#min' => 1,
    ];

    $form['offer_message'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Message'),
    ];

    $form['actions'] = ['#type' => 'actions'];
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Send offer'),
    ];

    return $form;
  }

  public function validateForm(array &$form, FormStateInterface $form_state) {
    $price = $form_state->getValue('offer_price');
    if (!is_numeric($price) || (int)$price <= 0) {
      $form_state->setErrorByName('offer_price', $this->t('Enter a valid price.'));
    }
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $uid = \Drupal::currentUser()->id();
    $car_id = $form_state->getValue('car_id');
    $price = (int)$form_state->getValue('offer_price');
    $message_text = $form_state->getValue('offer_message');

    $car = \Drupal::entityTypeManager()->getStorage('car_entity')->load($car_id);
    if (!$car) {
      $this->messenger()->addError($this->t('Car not found.'));
      return;
    }

    // Get taxonomy term 'Negotiate'
    $terms = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadByProperties(['name' => 'Negotiate']);
    $status_tid = $terms ? reset($terms)->id() : NULL;

    $seller_id = $car->get('user_id')->target_id;

    $offer = \Drupal::entityTypeManager()->getStorage('offer')->create([
      'title' => $this->t('Offer for @car by @user', ['@car' => $car->label(), '@user' => \Drupal::currentUser()->getDisplayName()]),
      'offer_price' => $price,
      'offer_message' => $message_text,
      'car_id' => $car->id(),
      'uid' => $uid,
      'seller_id' => $seller_id,
    ]);
    if ($status_tid) {
      $offer->set('offer_status', $status_tid);
    }
    $offer->save();

    // Notify seller: Message if available otherwise mail
    if (\Drupal::moduleHandler()->moduleExists('message')) {
      try {
        // Check if template exists
        $types = \Drupal::entityTypeManager()->getStorage('message')->loadByProperties(['template' => 'offer_sent']);
        // If message template exists as a Message type, create a Message entity by ID
        // Simpler approach: create Message entity with template id if available:
        /** @noinspection PhpUndefinedMethodInspection */
        $m = \Drupal::entityTypeManager()->getStorage('message')->load('offer_sent');
        if ($m) {
          $message_entity = Message::create(['template' => 'offer_sent']);
          $message_entity->setOwnerId($seller_id);
          $message_entity->setArguments([
            '@car' => $car->label(),
            '@price' => $price,
            '@customer' => \Drupal::currentUser()->getDisplayName(),
          ]);
          $message_entity->save();
        }
      }
      catch (\Throwable $e) {
        // ignore message errors, fallback to mail
      }
    }

    // Send email using core mail as fallback
    $seller = \Drupal\user\Entity\User::load($seller_id);
    if ($seller) {
      $mailManager = \Drupal::service('plugin.manager.mail');
      $module = 'carify_offer';
      $key = 'offer_received';
      $to = $seller->getEmail();
      $params['subject'] = $this->t('New offer for @car', ['@car' => $car->label()]);
      $params['message'] = $this->t("You have received a new offer for @car.\nPrice: @price\nMessage: @msg\nView offers: @url", [
        '@car' => $car->label(),
        '@price' => $price,
        '@msg' => $message_text,
        '@url' => \Drupal\Core\Url::fromRoute('carify_offer.seller_offers', [], ['absolute' => TRUE])->toString(),
      ]);
      $langcode = $seller->getPreferredLangcode();
      $mailManager->mail($module, $key, $to, $langcode, $params, NULL, TRUE);
    }

    $this->messenger()->addStatus($this->t('Offer sent to seller.'));
  }
}

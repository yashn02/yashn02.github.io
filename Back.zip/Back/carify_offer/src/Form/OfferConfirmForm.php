<?php

namespace Drupal\carify_offer\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\message\Entity\Message;

/**
 * Confirmation form for accept/reject actions.
 */
class OfferConfirmForm extends FormBase {

  public function getFormId() {
    return 'carify_offer_confirm_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state, $offer_id = NULL, $action = NULL) {
    $form['offer_id'] = ['#type' => 'value', '#value' => $offer_id];
    $form['action'] = ['#type' => 'value', '#value' => $action];

    $form['confirmation'] = [
      '#markup' => $this->t('Are you sure you want to @action this offer?', ['@action' => $action]),
    ];

    $form['confirm'] = [
      '#type' => 'submit',
      '#value' => $this->t('Yes, @action', ['@action' => $action]),
    ];

    $form['cancel'] = [
      '#type' => 'link',
      '#title' => $this->t('Cancel'),
      '#url' => \Drupal\Core\Url::fromRoute('carify_offer.seller_offers'),
    ];

    return $form;
  }

  public function validateForm(array &$form, FormStateInterface $form_state) {}

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $offer_id = $form_state->getValue('offer_id');
    $action = $form_state->getValue('action');

    $offer = \Drupal::entityTypeManager()->getStorage('offer')->load($offer_id);
    if (!$offer) {
      $this->messenger()->addError($this->t('Offer not found.'));
      // Redirect back to seller offers when missing.
      $form_state->setRedirect('carify_offer.seller_offers');
      return;
    }

    // Find matching taxonomy term by name (Accept/Reject)
    $terms = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadByProperties(['name' => ucfirst($action)]);
    if (!$terms) {
      $this->messenger()->addError($this->t('Status term "@action" missing in taxonomy.', ['@action' => $action]));
      $form_state->setRedirect('carify_offer.seller_offers');
      return;
    }
    $term = reset($terms);
    $offer->set('offer_status', $term->id());

    if (strtolower($action) === 'accept') {
      $offer->set('accepted_time', \Drupal::time()->getRequestTime());
      $offer->save();
      $this->notifyBuyerOnAccept($offer);
      $this->messenger()->addStatus($this->t('Offer accepted.'));

      // Redirect to car detail page so the accepted offer is visible on the car page.
      $car_id = $offer->get('car_id')->target_id;
      if ($car_id) {
        $form_state->setRedirect('carify_entity.view', ['car_entity' => $car_id]);
      }
      else {
        $form_state->setRedirect('carify_offer.seller_offers');
      }
      return;
    }
    elseif (strtolower($action) === 'reject') {
      $offer->save();
      $this->messenger()->addStatus($this->t('Offer rejected.'));
      // Redirect back to seller offers list.
      $form_state->setRedirect('carify_offer.seller_offers');
      return;
    } else {
      $offer->save();
      $this->messenger()->addStatus($this->t('Action applied.'));
      $form_state->setRedirect('carify_offer.seller_offers');
      return;
    }
  }

  protected function notifyBuyerOnAccept($offer) {
    $buyer = \Drupal\user\Entity\User::load($offer->get('uid')->target_id);
    $car = \Drupal::entityTypeManager()->getStorage('car_entity')->load($offer->get('car_id')->target_id);
    if ($buyer) {
      if (\Drupal::moduleHandler()->moduleExists('message')) {
        try {
          $message_entity = Message::create(['template' => 'offer_accepted']);
          $message_entity->setOwnerId($buyer->id());
          $message_entity->setArguments([
            '@car' => $car->label(),
            '@price' => $offer->get('offer_price')->value,
          ]);
          $message_entity->save();
        }
        catch (\Throwable $e) {
          // ignore
        }
      }

      // Send email
      $mailManager = \Drupal::service('plugin.manager.mail');
      $module = 'carify_offer';
      $key = 'offer_accepted';
      $to = $buyer->getEmail();
      $params['subject'] = $this->t('Congratulations — your offer was accepted');
      $params['message'] = $this->t('Congratulations! Your offer for @car has been accepted. Price: @price', [
        '@car' => $car->label(),
        '@price' => $offer->get('offer_price')->value,
      ]);
      $mailManager->mail($module, $key, $to, $buyer->getPreferredLangcode(), $params, NULL, TRUE);
    }
  }
}

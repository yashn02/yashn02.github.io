<?php

namespace Drupal\carify_offer\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\message\Entity\Message;

/**
 * Form used by seller to send counter-offer (negotiate).
 */
class OfferNegotiateForm extends FormBase {

  public function getFormId() {
    return 'carify_offer_negotiate_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state, $offer = NULL) {
    // Accept either an entity or an ID.
    $offer_id = is_object($offer) && method_exists($offer, 'id') ? $offer->id() : $offer;

    $offer_entity = \Drupal::entityTypeManager()->getStorage('offer')->load($offer_id);
    if (!$offer_entity) {
      return ['#markup' => $this->t('Offer not found.')];
    }

    $form['offer_id'] = ['#type' => 'value', '#value' => $offer_entity->id()];

    $form['offer_price'] = [
      '#type' => 'number',
      '#title' => $this->t('Counter price'),
      '#required' => TRUE,
      '#min' => 1,
    ];

    $form['offer_message'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Message'),
    ];

    $form['actions'] = ['#type' => 'actions'];
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Send counter-offer'),
    ];

    return $form;
  }

  public function validateForm(array &$form, FormStateInterface $form_state) {
    if ((int)$form_state->getValue('offer_price') <= 0) {
      $form_state->setErrorByName('offer_price', $this->t('Enter a valid price.'));
    }
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $parent_id = $form_state->getValue('offer_id');
    $parent = \Drupal::entityTypeManager()->getStorage('offer')->load($parent_id);
    if (!$parent) {
      $this->messenger()->addError($this->t('Original offer not found.'));
      return;
    }

    $car_id = $parent->get('car_id')->target_id;

    $new = \Drupal::entityTypeManager()->getStorage('offer')->create([
      'title' => $this->t('Counter-offer for @car', ['@car' => $car_id]),
      'offer_price' => (int)$form_state->getValue('offer_price'),
      'offer_message' => $form_state->getValue('offer_message'),
      'car_id' => $car_id,
      'uid' => \Drupal::currentUser()->id(),
      'seller_id' => $parent->get('seller_id')->target_id,
      'parent_offer' => $parent_id,
    ]);

    // Set status to 'Negotiate' if term exists.
    $terms = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadByProperties(['name' => 'Negotiate']);
    $status_tid = $terms ? reset($terms)->id() : NULL;
    if ($status_tid) {
      $new->set('offer_status', $status_tid);
    }

    $new->save();

    // Notify buyer/seller via Message or mail (omitted for brevity as previous code handles this).
    $this->messenger()->addStatus($this->t('Counter-offer sent.'));

    // Redirect to the newly created offer's view so workflow continues.
    $form_state->setRedirect('carify_offer.offer_view', ['offer' => $new->id()]);
  }
}

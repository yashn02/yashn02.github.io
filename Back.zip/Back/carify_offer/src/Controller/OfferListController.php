<?php

namespace Drupal\carify_offer\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Controller for listing offers for seller and buyer.
 */
class OfferListController extends ControllerBase {

  public function sellerOffers() {
    $uid = $this->currentUser()->id();
    $storage = \Drupal::entityTypeManager()->getStorage('offer');

    // Load offers where seller_id equals current user (offer entity has seller_id field)
    $query = \Drupal::entityQuery('offer')->accessCheck(TRUE);
    $query->condition('seller_id', $uid);
    $ids = $query->execute();
    $offers = $ids ? $storage->loadMultiple($ids) : [];

    return [
      '#theme' => 'seller_offers_page',
      '#offers' => $offers,
      '#cache' => ['max-age' => 0],
    ];
  }

  public function customerOffers() {
    $uid = $this->currentUser()->id();
    $storage = \Drupal::entityTypeManager()->getStorage('offer');

    // Use entityQuery with access checking for consistency.
    $query = \Drupal::entityQuery('offer')->accessCheck(TRUE);
    $query->condition('uid', $uid);
    $ids = $query->execute();
    $offers = $ids ? $storage->loadMultiple($ids) : [];

    return [
      '#theme' => 'seller_offers_page',
      '#offers' => $offers,
      '#cache' => ['max-age' => 0],
    ];
  }

  public function viewOffer($offer) {
    // If route passed scalar id, load entity. If an entity was passed, use it.
    if (is_scalar($offer)) {
      $offer = \Drupal::entityTypeManager()->getStorage('offer')->load($offer);
    }
    if (!$offer) {
      throw new \Symfony\Component\HttpKernel\Exception\NotFoundHttpException();
    }
    return [
      '#theme' => 'offer_item',
      '#offer' => $offer,
      '#cache' => ['max-age' => 0],
    ];
  }
}

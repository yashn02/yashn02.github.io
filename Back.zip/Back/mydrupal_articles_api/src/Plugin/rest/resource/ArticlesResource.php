<?php

namespace Drupal\mydrupal_articles_api\Plugin\rest\resource;

use Drupal\rest\Plugin\ResourceBase;
use Drupal\rest\ResourceResponse;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides Articles Resource.
 *
 * @RestResource(
 *   id = "articles_resource",
 *   label = @Translation("Articles Resource"),
 *   uri_paths = {
 *     "canonical" = "/api/articles"
 *   }
 * )
 */


class ArticlesResource extends ResourceBase {
  protected $entityTypeManager;

  public function __construct(array $configuration, $plugin_id, $plugin_definition, array $serializer_formats, $logger, $entity_type_manager) {
    parent::__construct($configuration, $plugin_id, $plugin_definition, $serializer_formats, $logger);
    $this->entityTypeManager = $entity_type_manager;
  }

  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->getParameter('serializer.formats'),
      $container->get('logger.factory')->get('rest'),
      $container->get('entity_type.manager')
    );
  }

  public function get() {
    $nodes = $this->entityTypeManager->getStorage('node')->loadByProperties(['type' => 'article']);
    $data = [];
    foreach ($nodes as $node) {
      $data[] = [
        'nid' => $node->id(),
        'title' => $node->getTitle(),
        'body' => $node->get('body')->value,
      ];
    }
    return new ResourceResponse($data);
  }
}
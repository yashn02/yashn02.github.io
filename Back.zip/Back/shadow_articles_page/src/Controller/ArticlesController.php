<?php

namespace Drupal\shadow_articles_page\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\DependencyInjection\ContainerInterface;
use GuzzleHttp\Client;

class ArticlesController extends ControllerBase {

  protected $httpClient;

  public function __construct(Client $http_client) {
    $this->httpClient = $http_client;
  }

  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('http_client')
    );
  }

  public function content() {
    try {
      // Fetch articles from MyDrupal API
      $response = $this->httpClient->get('http://localhost/mydrupal/web/api/articles', [
        'auth' => ['tester1', 'admin'], // Basic Auth credentials
        'headers' => ['Accept' => 'application/json']
      ]);

      $articles = json_decode($response->getBody(), TRUE);

      // Build render array with title and plain body text
      $items = [];
      foreach ($articles as $article) {
        $title = htmlspecialchars($article['title']);
        $body = strip_tags($article['body']); // Remove <p> and other HTML tags
        $items[] = [
          '#markup' => '<h3>' . $title . '</h3>' .
                       '<p>' . nl2br(htmlspecialchars($body)) . '</p>'
        ];
      }

      return [
        '#theme' => 'item_list',
        '#items' => $items,
        '#title' => $this->t('Articles from MyDrupal'),
        '#cache' => ['max-age' => 3600], // Cache for 1 hour
      ];

    } catch (\Exception $e) {
      return [
        '#markup' => $this->t('Error fetching articles: @message', ['@message' => $e->getMessage()]),
      ];
    }
  }
}
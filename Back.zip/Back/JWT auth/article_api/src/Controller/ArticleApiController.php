<?php

namespace Drupal\article_api\Controller;

use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Drupal\user\Entity\User;

class ArticleApiController {

  public function generateToken() {
    $currentUser = \Drupal::currentUser();
    if ($currentUser->isAnonymous()) {
      return new JsonResponse(['error' => 'Login required'], 403);
    }

    if (!$currentUser->hasPermission('administer articles api')) {
      return new JsonResponse(['error' => 'Access denied'], 403);
    }

    $uid = $currentUser->id();
    $roles = $currentUser->getRoles();
    $jwtService = \Drupal::service('article_api.jwt_service');
    $token = $jwtService->generateToken($uid, $roles);

    return new JsonResponse(['token' => $token]);
  }

  public function getArticles(Request $request) {
    $authHeader = $request->headers->get('Authorization');
    if (!$authHeader || !str_starts_with($authHeader, 'Bearer ')) {
      return new JsonResponse(['error' => 'Missing token'], 401);
    }

    $token = substr($authHeader, 7);
    $jwtService = \Drupal::service('article_api.jwt_service');
    $decoded = $jwtService->validateToken($token);

    if (!$decoded || empty($decoded['uid'])) {
      return new JsonResponse(['error' => 'Invalid token'], 403);
    }

    $user = User::load($decoded['uid']);
    if (!$user || !$user->isActive() || !$user->hasPermission('administer articles api')) {
      return new JsonResponse(['error' => 'Access denied'], 403);
    }

    $nodes = \Drupal::entityTypeManager()->getStorage('node')->loadByProperties(['type' => 'article']);
    $articles = [];
    foreach ($nodes as $node) {
      $articles[] = [
        'id' => $node->id(),
        'title' => $node->getTitle(),
        'body' => $node->get('body')->value,
      ];
    }

    return new JsonResponse($articles);
  }
}
<?php

namespace Drupal\article_consumer\Service;

use GuzzleHttp\Client;

class ApiRequestService {

  public function getToken() {
    $oauthToken = $this->getOAuthToken();
    if (!$oauthToken) {
      return FALSE;
    }

    $client = new Client();
    $response = $client->post('http://localhost/mydrupal/web/api/token', [
      'headers' => [
        'Authorization' => 'Bearer ' . $oauthToken, // OAuth token stays here
      ],
    ]);

    $data = json_decode($response->getBody(), TRUE);
    return $data['token'] ?? FALSE;
  }

  private function getOAuthToken() {
    $client = new Client();
    $response = $client->post('http://localhost/mydrupal/web/oauth/token', [
      'form_params' => [
        'grant_type' => 'client_credentials',
        'client_id' => 'article_consumer',
        'client_secret' => 'a0df7b076a4d93d00520980314eb3d0b59d65a27d45bc6772b49b546d7c0492',
        'scope' => 'articles_api',
      ],
    ]);

    $data = json_decode($response->getBody(), TRUE);
    return $data['access_token'] ?? FALSE;
  }

  public function fetchArticles($token) {
    $client = new Client();
    $response = $client->get('http://localhost/mydrupal/web/api/articles', [
      'headers' => [
        'X-JWT-Authorization' => 'Bearer ' . $token, // ✅ Updated header
      ],
    ]);

    return json_decode($response->getBody(), TRUE);
  }
}
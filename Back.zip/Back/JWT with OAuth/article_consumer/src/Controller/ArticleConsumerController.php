<?php

namespace Drupal\article_consumer\Controller;

use Symfony\Component\HttpFoundation\JsonResponse;

class ArticleConsumerController {

  public function fetchArticles() {
    $apiService = \Drupal::service('article_consumer.api_request');

    // Step 1: Get JWT token from server using OAuth token
    $token = $apiService->getToken();
    if (!$token) {
      return new JsonResponse(['error' => 'Failed to get token'], 500);
    }

    // Step 2: Fetch articles using JWT token
    $articles = $apiService->fetchArticles($token);
    return new JsonResponse($articles);
  }
}
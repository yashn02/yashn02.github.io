<?php

namespace Drupal\article_api\Controller;

use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

class ArticleApiController {

  /**
   * Generate JWT token after validating OAuth token.
   */
  public function generateToken(Request $request) {
    // Validate OAuth token from Authorization header
    $authHeader = $request->headers->get('Authorization');
    if (!$authHeader || !str_starts_with($authHeader, 'Bearer ')) {
      return new JsonResponse(['error' => 'Missing OAuth token'], 401);
    }

    $oauthToken = substr($authHeader, 7);
    // For simplicity, assume OAuth token is valid (skip introspection)

    // Generate JWT as before
    $uid = 1; // Static or map from OAuth token if needed
    $roles = ['authenticated']; // Or derive from OAuth scopes
    $jwtService = \Drupal::service('article_api.jwt_service');
    $token = $jwtService->generateToken($uid, $roles);

    return new JsonResponse(['token' => $token]);
  }

  /**
   * Fetch articles using JWT token.
   */
  public function getArticles(Request $request) {
    $authHeader = $request->headers->get('X-JWT-Authorization');
if (!$authHeader || !str_starts_with($authHeader, 'Bearer ')) {
  return new JsonResponse(['error' => 'Missing JWT token'], 401);
}

    $token = substr($authHeader, 7);
    $jwtService = \Drupal::service('article_api.jwt_service');
    $decoded = $jwtService->validateToken($token);

    if (!$decoded || empty($decoded['uid'])) {
      return new JsonResponse(['error' => 'Invalid token'], 403);
    }

    // Fetch articles
    $nodes = \Drupal::entityTypeManager()->getStorage('node')->loadByProperties(['type' => 'article']);
    $articles = [];
    foreach ($nodes as $node) {
      $articles[] = [
        'id' => $node->id(),
        'title' => $node->getTitle(),
        'body' => $node->get('body')->value,
      ];
    }

    return new JsonResponse($articles);
  }
}
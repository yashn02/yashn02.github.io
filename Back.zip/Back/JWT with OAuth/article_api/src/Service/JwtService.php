<?php

namespace Drupal\article_api\Service;

class JwtService {

  private function base64UrlEncode($data) {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
  }

  private function base64UrlDecode($data) {
    return base64_decode(strtr($data, '-_', '+/'));
  }

  public function generateToken($uid, $roles) {
    $header = ['alg' => 'RS256', 'typ' => 'JWT'];
    $payload = [
      'uid' => $uid,
      'roles' => $roles,
      'iat' => time(),
      'exp' => time() + 3600,
    ];

    $headerEncoded = $this->base64UrlEncode(json_encode($header));
    $payloadEncoded = $this->base64UrlEncode(json_encode($payload));
    $data = $headerEncoded . '.' . $payloadEncoded;

    $privateKeyPath = \Drupal::service('settings')->get('jwt_private_key_path');
    $privateKey = file_get_contents($privateKeyPath);
    openssl_sign($data, $signature, $privateKey, OPENSSL_ALGO_SHA256);
    $signatureEncoded = $this->base64UrlEncode($signature);

    return $data . '.' . $signatureEncoded;
  }

  public function validateToken($token) {
    $parts = explode('.', $token);
    if (count($parts) !== 3) {
      return FALSE;
    }

    [$header, $payload, $signature] = $parts;
    $data = $header . '.' . $payload;
    $decodedSignature = $this->base64UrlDecode($signature);

    $publicKeyPath = \Drupal::service('settings')->get('jwt_public_key_path');
    $publicKey = file_get_contents($publicKeyPath);

    $verified = openssl_verify($data, $decodedSignature, $publicKey, OPENSSL_ALGO_SHA256);

// Add debug logs here
  \Drupal::logger('article_api')->notice('Debug log triggered');

    if ($verified === 1) {
      return json_decode($this->base64UrlDecode($payload), TRUE);
    }
    return FALSE;
  }
}
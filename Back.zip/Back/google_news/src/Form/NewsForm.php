<?php

namespace Drupal\google_news\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

class NewsForm extends FormBase {

  public function getFormId() {
    return 'google_news_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['get_news'] = [
      '#type' => 'submit',
      '#value' => 'Get News',
    ];

    // Display fetched news if available
    if ($form_state->get('news_data')) {
      $form['news'] = [
        '#type' => 'markup',
        '#markup' => '<h2>Indian Headlines</h2>',
      ];
$news_items = array_slice($form_state->get('news_data'), 0, 5);
      foreach ($news_items as $news_item) {
        $form['news_' . md5($news_item['title'])] = [
          '#type' => 'markup',
          '#markup' => '<p><strong>' . $news_item['title'] . '</strong><br>' . $news_item['description'] . '</p><hr>',
        ];
      }
    }

    return $form;
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $api_key = '30e72b13eafa5c908abfbcf4d2fa1fc1';
    $url = 'https://gnews.io/api/v4/top-headlines?country=in&lang=en&apikey=' . $api_key;

    try {
      $client = \Drupal::httpClient();
      $response = $client->get($url);
      $data = json_decode($response->getBody(), TRUE);
      $form_state->set('news_data', $data['articles'] ?? []);
    } catch (\Exception $e) {
      $form_state->set('news_data', [['title' => 'Error', 'description' => $e->getMessage()]]);
    }

    $form_state->setRebuild(TRUE);
  }
}
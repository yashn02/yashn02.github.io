/**
 * carify theme JS
 * - small interactions: mobile menu, car gallery, contact form enhancements
 */

(function (Drupal, $) {
  Drupal.behaviors.carify = {
    attach: function (context, settings) {
      // Simple click handler for image thumbnails if present.
      $('.car-gallery .thumb', context).once('carify-thumb').on('click', function () {
        var src = $(this).data('src');
        if (src) {
          $('.car-gallery .main-img').attr('src', src);
        }
      });

      // Example: toggle search filters on mobile
      $('.carify-toggle-filters', context).once('carify-tog').on('click', function () {
        $('.carify-filters').toggleClass('open');
      });
    }
  };
})(Drupal, jQuery);

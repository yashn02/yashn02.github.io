<?php

namespace Drupal\carify_entity\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Connection;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Url;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Drupal\Core\Entity\EntityTypeManagerInterface;

/**
 * Returns responses for Car entity routes.
 */
class CarController extends ControllerBase {

  /**
   * Database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * Entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * Dependency injection.
   */
  public static function create(ContainerInterface $container) {
    $instance = new static();
    $instance->database = $container->get('database');
    $instance->entityTypeManager = $container->get('entity_type.manager');
    return $instance;
  }

  /**
   * Lists all cars at /carify.
   */
  public function list() {
    // Load car entities so field data (images) are available.
    $storage = $this->entityTypeManager->getStorage('car_entity');

    // Entity queries must explicitly set access checking.
    $query = \Drupal::entityQuery('car_entity')
      ->accessCheck(TRUE)
      ->condition('status', 1)
      ->sort('created', 'DESC')
      ->range(0, 20);

    $ids = $query->execute();
    $entities = $storage->loadMultiple($ids);

    $cars = [];

    foreach ($entities as $entity) {
      // Prepare image render array (uses field display settings or an image style).
      $image_render = NULL;
      if ($entity->hasField('field_images') && !$entity->get('field_images')->isEmpty()) {
        // Render the field with a simple image style (thumbnail) for list.
        $image_render = $entity->get('field_images')->view(['label' => 'hidden', 'type' => 'image_style', 'settings' => ['image_style' => 'thumbnail']]);
      }

      $cars[] = [
        'title' => $entity->label(),
        'price' => $entity->get('field_price')->value,
        'year' => $entity->get('field_year')->value,
        'url' => Url::fromRoute('carify_entity.view', ['car_entity' => $entity->id()])->toString(),
        'image' => $image_render,
      ];
    }

    return [
      '#theme' => 'carify_car_list',
      '#cars' => $cars,
      '#cache' => ['tags' => ['car_entity_list']],
      '#attached' => [
        'library' => [
          'carify/global-styling',
        ],
      ],
    ];
  }

  /**
   * Displays a single car at /car/{car_entity}.
   */
  public function view($car_entity) {
    // Load the car entity so fields (including images) are available.
    $entity = $this->entityTypeManager->getStorage('car_entity')->load($car_entity);

    // If not found, 404.
    if (!$entity) {
      throw new NotFoundHttpException();
    }

    // Render images (use a larger image style for detail page).
    $images_render = NULL;
    if ($entity->hasField('field_images') && !$entity->get('field_images')->isEmpty()) {
      $images_render = $entity->get('field_images')->view(['label' => 'hidden', 'type' => 'image_style', 'settings' => ['image_style' => 'large']]);
    }

    // Prepare a simple data object for the Twig template (keeps existing template keys).
    $car = new \stdClass();
    $car->title = $entity->label();
    $car->field_price = $entity->get('field_price')->value;
    $car->field_year = $entity->get('field_year')->value;
    $car->field_description = $entity->hasField('field_description') ? $entity->get('field_description')->value : '';

    return [
      '#theme' => 'carify_car_detail',
      '#car' => $car,
      '#images' => $images_render,
      '#cache' => ['tags' => $entity->getCacheTags()],
      '#attached' => [
        'library' => [
          'carify/global-styling',
        ],
      ],
    ];
  }
}
